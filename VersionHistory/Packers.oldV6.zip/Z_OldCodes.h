﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,11.12.2018</created>
/// <changed>ʆϒʅ,11.12.2018</changed>
// ********************************************************************************

#pragma once


#ifndef Z_OLDCODES_H
#define Z_OLDCODES_H


void muTex ();


#endif // !Z_OLDCODES_H