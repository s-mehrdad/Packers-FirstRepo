# Introduction 
Packers is a funny game that is intended to make people more aware of environment while laughing.
The inspiration behind it comes from looking at what people do and the old packman game.

The project was originally uploaded into the GitHub account of the creator, then he decided to move to Azure to have a better access on things.

The URLs to access the project and the creator himself are:
https://github.com/Mehrdad-Solimanimajd/
https://dev.azure.com/BirdSofts

The below emails can be used to contact the creator in any case, if further information is needed.
s.mehrdad.47@gamil.com
s.mehrdad.47@outlook.com

# Getting Started
1.	Installation process:
Just a simple console game written in C++. If you are a user without any knowledge about programming and want to see what is what, just open the .exe application file (it is not a virus :p ) and see your full. If you don't have that knowledge eider, just do let it go without checking anything and wait for the release version.

2.	Software dependencies:
For simple user probably a machine which runs on windows.
Advanced users?! Well they can find their ways around themselves. :p

3.	Latest releases:
Still no release, just coding and debugging

4.	API references
Windows

# Build and Test
Do use Visual Studio or know what you are doing before doing anything.

# Contribute
I appreciate any contribution from anyone, who sees that the project deserves his precious time.

# Copyright
This is not a freeware and the source code is copyrighted. The project was originally uploaded in GitHub, since the creator didn't have any access to Microsoft Azure. The Source code can just be used for teaching purposes. For any other uses the written acknowledgement and permission is needed.