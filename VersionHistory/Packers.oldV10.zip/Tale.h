﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,01.04.2019</created>
/// <changed>ʆϒʅ,01.04.2019</changed>
// ********************************************************************************

#pragma once


#ifndef TALE_H
#define TALE_H


class Tale
{
  struct storyLine;
  struct creatures;

public:
  Tale ( unsigned char );
  void newSetter ( void );

};


#endif // !TALE_H
