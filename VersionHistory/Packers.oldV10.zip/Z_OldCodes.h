﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,11.12.2018</created>
/// <changed>ʆϒʅ,01.04.2019</changed>
// ********************************************************************************

#pragma once


#ifndef Z_OLDCODES_H
#define Z_OLDCODES_H


void muTex ();


#endif // !Z_OLDCODES_H
