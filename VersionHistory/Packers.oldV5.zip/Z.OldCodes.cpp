﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,01.12.2018</created>
/// <changed>ʆϒʅ,01.12.2018</changed>
// ********************************************************************************

#include "pch.h"


//#include <mutex>
//#include <condition_variable>
//#include <algorithm>

//std::mutex m;
//std::condition_variable cv;

//// waiting for the awakening signal
//{
//std::unique_lock<std::mutex> lk (m);
//cv.wait (lk, [] { return ready; });
//}

//// sending the awakening signal
//{
//std::lock_guard<std::mutex> lk (m);
//ready = true;
//cv.notify_one ();
//}