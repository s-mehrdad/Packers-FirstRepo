﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,06.11.2018</created>
/// <changed>ʆϒʅ,23.06.2019</changed>
// ********************************************************************************

#pragma once


#ifndef SURROUND_H
#define SURROUND_H


//class Surround
//{
  //struct titleBar;
  //struct menus;
  //struct guideBar;
  //struct status;
//public:
//  Surround ( const unsigned char& );
//  void setter ( void );

  //static void menusSetter ( const unsigned short&, const bool& );
//};


#endif // !SURROUND_H
