﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,11.12.2018</created>
/// <changed>ʆϒʅ,13.10.2019</changed>
// ********************************************************************************

#ifndef Z_OLDCODES_H
#define Z_OLDCODES_H


#include <mutex>
#include <condition_variable>
#include <algorithm>


void muTex ();


#endif // !Z_OLDCODES_H
