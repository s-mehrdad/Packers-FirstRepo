
#pragma once


#ifndef PACKER_H
#define PACKER_H



class Packer {
  char Sign;
public:
  bool RchanceL;
  COORD position;
  unsigned short state;
  Packer (short);
  static void blinkPacking (COORD, unsigned char);
  static void hQuickMovement (std::list<Packer>, unsigned char);
  static void hNormalMovement (std::list<Packer>, unsigned char);
  static void hSlowMovement (std::list<Packer>, unsigned char);
};



#endif // !PACKER_H
