﻿

#include "pch.h"
#include "Packer.h"
#include "ConsoleAdjustments.h"
#include "Shared.h"
#include "Area.h"



Packer::Packer (short quickReSeed) {

  // random first placement
  int i { 0 };
  int j { 0 };
  srand ((unsigned int)time (NULL) + quickReSeed);
  do {
    i = rand () % (19 - 3) + 3;
    j = rand () % (89 - 3) + 3;
  } while (i % 2 == 0 || j % 2 == 0);
  gotoXY (j, i); ColourCout (u8"☻", 0x0f);
  position.X = j;
  position.Y = i;

  // random direction
  int d { 0 };
  //srand ((unsigned int)time (NULL) + quickReSeed);
  d = (rand () % (1111 - 20) + 20);
  if (d % 2 == 0) {
    RchanceL = true;
  }
  else {
    RchanceL = false;
  }

  // random state
  int s { 0 };
  s = (rand () % 3 + 1);
  if (s == 1)
    state = 1000; // normal
  if (s == 2)
    state = 2000; // not in the mood
  if (s == 3)
    state = 3000; // tired
};


//add:
//Packer (//userchoice) :Sign () {};


// no static here, since it is not allowed
void Packer::blinkPacking (COORD position, unsigned char mode) {
  //▪▫
  //add: if for characters
  //add: state show/save
  short modeToMilliS { 1 };
  switch (mode) {
  case 1:
    modeToMilliS = 500;
    break;
  case 2:
    modeToMilliS = 400;
    break;
  case 3:
    modeToMilliS = 200;
    break;
  case 4:
    modeToMilliS = 1000;
    break;
  }
  std::this_thread::sleep_for (std::chrono::milliseconds (1000));;
  //do {} while (protectedSetCursor == true);
  //gotoXY (position.X, position.Y);
  //ColourCout (u8"▪", 0x0f);
  test2 (u8"▪", 0x0f, position.X, position.Y);
  std::this_thread::sleep_for (std::chrono::milliseconds (modeToMilliS));;
  //do {} while (protectedSetCursor == true);
  //gotoXY (position.X, position.Y);
  //ColourCout (u8"☻", 0x0f);
  test2 (u8"☻", 0x0f, position.X, position.Y);
  std::this_thread::sleep_for (std::chrono::milliseconds (modeToMilliS));;
};


void Packer::hQuickMovement (std::list<Packer> input, unsigned char mode) {
  if (input.size () != 0) {
    short modeToMilliS { 1 };
    COORD position;
    switch (mode) {
    case 1:
      modeToMilliS = 500;
      break;
    case 2:
      modeToMilliS = 400;
      break;
    case 3:
      modeToMilliS = 200;
      break;
    case 4:
      modeToMilliS = 1000;
      break;
    }
    for (int i = 0; i < 1000; i++) {
      do {
        if (input.front ().RchanceL == true) {
          if (input.front ().position.X != 87) {

            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8" ", 0x0f);
            input.front ().position.X += 2;
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8"☻", 0x0f);
            position.X = input.front ().position.X;
            position.Y = input.front ().position.Y;
            //Area::yellow (position);
            Packer::blinkPacking (position, 3);
            input.emplace_back (input.front ());
            input.pop_front ();
            //Area::green (position);
          }
          else
            input.front ().RchanceL = false;
          std::this_thread::sleep_for (std::chrono::milliseconds (modeToMilliS));;
        }
        else
          if (input.front ().position.X != 3) {
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8" ", 0x0f);
            input.front ().position.X -= 2;
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8"☻", 0x0f);
            position.X = input.front ().position.X;
            position.Y = input.front ().position.Y;
            //Area::yellow (position);
            Packer::blinkPacking (position, 3);
            input.emplace_back (input.front ());
            input.pop_front ();
            //Area::green (position);
          }
          else
            input.front ().RchanceL = true;
        std::this_thread::sleep_for (std::chrono::milliseconds (modeToMilliS));;
        //add: while user decide to involve himself

        //bug: next expression needs more thought
      } while (input.size () != 0);
    }
  }
};


void Packer::hNormalMovement (std::list<Packer> input, unsigned char mode) {
  if (input.size () != 0) {
    short modeToMilliS { 1 };
    COORD position;
    switch (mode) {
    case 1:
      modeToMilliS = 500;
      break;
    case 2:
      modeToMilliS = 400;
      break;
    case 3:
      modeToMilliS = 200;
      break;
    case 4:
      modeToMilliS = 1000;
      break;
    }
    for (int i = 0; i < 1000; i++) {
      do {
        if (input.front ().RchanceL == true) {
          if (input.front ().position.X != 87) {
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8" ", 0x0f);
            input.front ().position.X += 2;
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8"☻", 0x0f);
            position.X = input.front ().position.X;
            position.Y = input.front ().position.Y;
            //Area::yellow (position);
            Packer::blinkPacking (position, 3);
            input.emplace_back (input.front ());
            input.pop_front ();
            //Area::green (position);
          }
          else
            input.front ().RchanceL = false;
          std::this_thread::sleep_for (std::chrono::milliseconds (modeToMilliS));;
        }
        else
          if (input.front ().position.X != 3) {
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8" ", 0x0f);
            input.front ().position.X -= 2;
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8"☻", 0x0f);
            position.X = input.front ().position.X;
            position.Y = input.front ().position.Y;
            //Area::yellow (position);
            Packer::blinkPacking (position, 3);
            input.emplace_back (input.front ());
            input.pop_front ();
            //Area::green (position);
          }
          else
            input.front ().RchanceL = true;
        std::this_thread::sleep_for (std::chrono::milliseconds (modeToMilliS));;
        //add: while user decide to involve himself

        //bug: next expression needs more thought
      } while (input.size () != 0);
    }
  }
};


void Packer::hSlowMovement (std::list<Packer> input, unsigned char mode) {
  if (input.size () != 0) {
    short modeToMilliS { 1 };
    COORD position;
    switch (mode) {
    case 1:
      modeToMilliS = 500;
      break;
    case 2:
      modeToMilliS = 400;
      break;
    case 3:
      modeToMilliS = 200;
      break;
    case 4:
      modeToMilliS = 1000;
      break;
    }
    for (int i = 0; i < 1000; i++) {
      do {
        if (input.front ().RchanceL == true) {
          if (input.front ().position.X != 87) {
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8" ", 0x0f);
            input.front ().position.X += 2;
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8"☻", 0x0f);
            position.X = input.front ().position.X;
            position.Y = input.front ().position.Y;
            //Area::yellow (position);
            Packer::blinkPacking (position, 3);
            input.emplace_back (input.front ());
            input.pop_front ();
            //Area::green (position);
          }
          else
            input.front ().RchanceL = false;
          std::this_thread::sleep_for (std::chrono::milliseconds (modeToMilliS));;
        }
        else
          if (input.front ().position.X != 3) {
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8" ", 0x0f);
            input.front ().position.X -= 2;
            do {} while (protectedSetCursor == true);
            gotoXY (input.front ().position.X, input.front ().position.Y);
            ColourCout (u8"☻", 0x0f);
            position.X = input.front ().position.X;
            position.Y = input.front ().position.Y;
            //Area::yellow (position);
            Packer::blinkPacking (position, 3);
            input.emplace_back (input.front ());
            input.pop_front ();
            //Area::green (position);
          }
          else
            input.front ().RchanceL = true;
        std::this_thread::sleep_for (std::chrono::milliseconds (modeToMilliS));;
        //add: while user decide to involve himself

        //bug: next expression needs more thought
      } while (input.size () != 0);
    }
  }
};