
#pragma once


#ifndef CONSOLEADJUSTMENTS_H
#define CONSOLEADJUSTMENTS_H




void ConsoleFont_SizeColour (COORD, LPCWSTR, WORD);
void ConsoleScreen_SizeColourPosition (COORD, COORD, COLORREF);
void ConsoleCursor_State (bool);
void ColourCout (std::string, WORD);
void gotoXY (int, int);
void test (std::string, WORD, int, int);
void test3 (void);




#endif // !CONSOLEADJUSTMENTS_H