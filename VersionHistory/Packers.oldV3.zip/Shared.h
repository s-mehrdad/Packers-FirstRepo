
#pragma once


#ifndef SHARED_H
#define SHARED_H


extern bool running;

extern bool protectedSetCursor;

extern struct queueFeed {
  COORD position;
  std::string str;
  WORD colour;
} QF;
extern std::list<queueFeed> QQ;

void loading (void);
void pressed (unsigned char[], bool);
void test2 (std::string, WORD, int, int);


#endif // !SHARED_H